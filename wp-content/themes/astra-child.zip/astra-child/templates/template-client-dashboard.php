<?php
/* Template Name: client-dashboard */
?>
<?php
get_sidebar();
?>
 <!-- Main Content -->

 <main class="content">
        <h2>Welcome to AdminLTE-Style Sidebar</h2>
        <p>This is the main content area.</p>
</main>
     
  


